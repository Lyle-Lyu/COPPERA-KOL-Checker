# COPPERA KOL CHECKER

This is a React-based evaluation tool for assessing TikTok KOLs.